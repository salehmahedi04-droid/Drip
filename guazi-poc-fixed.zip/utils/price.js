const RATE = Number(process.env.USD_TO_DZD_RATE) || 240;
const usdToDzd = (usd) => Math.round(Number(usd) * RATE);
const dzdToUsdFloor = (dzd) => Math.floor(Number(dzd) / RATE);
module.exports = { RATE, usdToDzd, dzdToUsdFloor };
