const http = require('http');
const fs = require('fs');
const path = require('path');
const { searchVehicles, MAKES, FUELS, TRANSMISSIONS, DataError } = require('./services/apify');
const { RATE } = require('./utils/price');

const PORT = process.env.PORT || 3000;
const INDEX = path.join(__dirname, 'public', 'index.html');

function validate(b) {
  if (!b || typeof b !== 'object') return null;
  const query = typeof b.query === 'string' ? b.query.trim().slice(0, 80) : '';
  if (!/^[\p{L}\p{N} .\-+]*$/u.test(query)) return null;
  const brand = typeof b.brand === 'string' ? b.brand : '';
  const fuel = typeof b.fuel === 'string' ? b.fuel : '';
  const transmission = typeof b.transmission === 'string' ? b.transmission : '';
  if (brand && !MAKES.includes(brand)) return null;
  if (fuel && !FUELS.includes(fuel)) return null;
  if (transmission && !TRANSMISSIONS.includes(transmission)) return null;
  let maxBudgetDzd = 0;
  if (b.maxBudgetDzd !== undefined && b.maxBudgetDzd !== null && b.maxBudgetDzd !== '') {
    maxBudgetDzd = Number(b.maxBudgetDzd);
    if (!Number.isFinite(maxBudgetDzd) || maxBudgetDzd < 0 || maxBudgetDzd > 1e10) return null;
  }
  return { query, brand, fuel, transmission, maxBudgetDzd };
}

function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
    return fs.readFile(INDEX, (e, d) => e ? json(res, 500, { error: 'Unable to load prototype.' }) : (res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }), res.end(d)));
  }
  if (req.method === 'GET' && url === '/api/health') return json(res, 200, { ok: true, rate: RATE });
  if (req.method === 'GET' && url === '/api/options') return json(res, 200, { brands: MAKES, fuels: FUELS, transmissions: TRANSMISSIONS, rate: RATE });
  if (req.method === 'POST' && url === '/api/search') {
    let body = '';
    for await (const c of req) { body += c; if (body.length > 5000) return json(res, 413, { error: 'Invalid search.' }); }
    let parsed; try { parsed = JSON.parse(body); } catch { return json(res, 400, { error: 'Please check your search criteria.' }); }
    const params = validate(parsed);
    if (!params) return json(res, 400, { error: 'Please check your search criteria.' });
    try {
      const vehicles = await searchVehicles(params);
      if (!vehicles.length) return json(res, 200, { vehicles: [], message: 'No vehicles found.' });
      return json(res, 200, { vehicles, rate: RATE });
    } catch (e) {
      if (e instanceof DataError) return json(res, 502, { error: 'Vehicle data could not be processed.' });
      console.error('[search] failed:', e.message);
      return json(res, 502, { error: 'Unable to retrieve vehicle data right now.' });
    }
  }
  json(res, 404, { error: 'Not found.' });
}).listen(PORT, '0.0.0.0', () => console.log(`Listening on ${PORT}`));
