// Server-side Apify integration. Never expose APIFY_API_TOKEN to the browser.
const { usdToDzd } = require('../utils/price');

const ACTOR = process.env.APIFY_ACTOR_ID || 'gfhoogZ4jRWaAdSpk';
const START_URL = process.env.GUAZI_START_URL || 'https://en.guazi.com/used-cars?brandId=1207&roadHaul=24000%2C&detectionLevels=S&fuelType=2&page=1';
const MOCK_MODE = String(process.env.MOCK_MODE || 'true').toLowerCase() === 'true';

const MAKES = ['BMW','Toyota','BYD','Geely','Audi','Mercedes-Benz','Honda','Hyundai','Nissan','Chery','Jetour','Changan','Great Wall','Xiaomi','Li Auto','Volkswagen'];
const FUELS = ['Gasoline','BEV','Hybrid','Plug-in hybrid','Range-extended'];
const TRANSMISSIONS = ['AT','MT'];

class ApifyError extends Error {}
class DataError extends Error {}

function parseNumber(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'string') return undefined;
  const n = Number(value.replace(/[^0-9.]/g, ''));
  return Number.isFinite(n) ? n : undefined;
}

function normalize(item) {
  if (!item || typeof item !== 'object' || typeof item.title !== 'string') return null;

  const priceUsd = parseNumber(item.price);
  const mileageKm = parseNumber(item.mileage);
  const year = typeof item.mfgDate === 'string' ? Number(item.mfgDate.slice(0, 4)) : undefined;

  const out = {
    title: item.title,
    brand: item.brandName,
    mfgYear: Number.isFinite(year) ? year : undefined,
    mileageKm,
    fuelType: item.fuelTypeName,
    transmission: item.transmission,
    url: item.url,
    imageUrl: item.image,
    priceUsd: priceUsd,
    priceDzd: priceUsd !== undefined ? usdToDzd(priceUsd) : undefined,
  };

  return Object.fromEntries(Object.entries(out).filter(([, v]) => v !== undefined && v !== null && v !== ''));
}

function applyFilters(list, { query, brand, fuel, transmission, maxBudgetDzd }) {
  const q = (query || '').toLowerCase().trim();
  return list.filter(v => {
    const hay = `${v.title || ''} ${v.brand || ''}`.toLowerCase();
    if (q && !q.split(/\s+/).every(token => hay.includes(token))) return false;
    if (brand && String(v.brand || '').toLowerCase() !== brand.toLowerCase()) return false;
    if (fuel && String(v.fuelType || '').toLowerCase() !== fuel.toLowerCase()) return false;
    if (transmission && String(v.transmission || '').toLowerCase() !== transmission.toLowerCase()) return false;
    if (maxBudgetDzd && (v.priceDzd === undefined || v.priceDzd > maxBudgetDzd)) return false;
    return true;
  });
}

function mockVehicles() {
  return [
    { title:'BMW 3 Series', brand:'BMW', mfgYear:2023, mileageKm:18000, fuelType:'Gasoline', transmission:'AT', priceUsd:8000, priceDzd:usdToDzd(8000), imageUrl:'', url:'https://en.guazi.com/' },
    { title:'Toyota Camry', brand:'Toyota', mfgYear:2022, mileageKm:24000, fuelType:'Gasoline', transmission:'AT', priceUsd:10500, priceDzd:usdToDzd(10500), imageUrl:'', url:'https://en.guazi.com/' },
    { title:'BYD Qin Plus', brand:'BYD', mfgYear:2023, mileageKm:15000, fuelType:'BEV', transmission:'AT', priceUsd:9000, priceDzd:usdToDzd(9000), imageUrl:'', url:'https://en.guazi.com/' },
  ];
}

function buildActorInput() {
  return {
    startUrls: [{ url: START_URL }],
    maxItemsPerUrl: 50,
    siteCountry: 'global',
    language: 'same_as_url',
  };
}

async function runActor(input) {
  const token = process.env.APIFY_API_TOKEN;
  if (!token) throw new ApifyError('missing token');
  const url = `https://api.apify.com/v2/acts/${ACTOR}/run-sync-get-dataset-items?timeout=120&clean=true`;
  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(input),
      signal: AbortSignal.timeout(130000),
    });
  } catch (e) {
    throw new ApifyError('network');
  }
  if (!res.ok) {
    console.error('[apify] HTTP', res.status);
    throw new ApifyError('http ' + res.status);
  }
  const data = await res.json().catch(() => null);
  if (!Array.isArray(data)) throw new DataError('unexpected dataset shape');
  return data;
}

async function searchVehicles(params) {
  if (MOCK_MODE) return applyFilters(mockVehicles(), params);
  const raw = await runActor(buildActorInput());
  const normalized = raw.map(normalize).filter(Boolean);
  if (raw.length && !normalized.length) throw new DataError('no usable items');
  return applyFilters(normalized, params);
}

module.exports = { searchVehicles, buildActorInput, normalize, applyFilters, MAKES, FUELS, TRANSMISSIONS, ApifyError, DataError };
